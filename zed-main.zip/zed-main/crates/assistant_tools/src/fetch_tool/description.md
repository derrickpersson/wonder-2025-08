Fetches a URL and returns the content as Markdown.
