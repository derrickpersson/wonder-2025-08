Reads the content of the given file in the project.

- Never attempt to read a path that hasn't been previously mentioned.
