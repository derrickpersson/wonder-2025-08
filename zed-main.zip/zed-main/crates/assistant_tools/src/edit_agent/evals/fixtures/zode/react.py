class InputCell:
    def __init__(self, initial_value):
        self.value = None


class ComputeCell:
    def __init__(self, inputs, compute_function):
        self.value = None

    def add_callback(self, callback):
        pass

    def remove_callback(self, callback):
        pass
