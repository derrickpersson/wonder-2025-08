Creates a new directory at the specified path within the project. Returns confirmation that the directory was created.

This tool creates a directory and all necessary parent directories (similar to `mkdir -p`). It should be used whenever you need to create new directories within the project.
