Moves or rename a file or directory in the project, and returns confirmation that the move succeeded.
If the source and destination directories are the same, but the filename is different, this performs
a rename. Otherwise, it performs a move.

This tool should be used when it's desirable to move or rename a file or directory without changing its contents at all.
