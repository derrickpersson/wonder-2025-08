Lists files and directories in a given path. Prefer the `grep` or `find_path` tools when searching the codebase.
