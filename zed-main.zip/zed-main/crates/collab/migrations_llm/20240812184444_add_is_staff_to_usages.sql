alter table usages add column is_staff boolean not null default false;
