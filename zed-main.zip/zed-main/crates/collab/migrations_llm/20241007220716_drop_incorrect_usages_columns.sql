alter table usages
    drop column cache_creation_input_tokens_this_month,
    drop column cache_read_input_tokens_this_month;
