ALTER TABLE worktree_repositories
ADD COLUMN worktree_repositories VARCHAR NULL;
