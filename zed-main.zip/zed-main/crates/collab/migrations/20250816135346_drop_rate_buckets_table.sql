drop table rate_buckets;
