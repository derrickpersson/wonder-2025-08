ALTER TABLE "worktree_settings_files" ADD COLUMN "kind" VARCHAR;
