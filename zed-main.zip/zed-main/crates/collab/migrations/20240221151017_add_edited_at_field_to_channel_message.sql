ALTER TABLE channel_messages ADD edited_at TIMESTAMP DEFAULT NULL;
