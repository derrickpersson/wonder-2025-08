ALTER TABLE rooms ADD COLUMN enviroment TEXT;
