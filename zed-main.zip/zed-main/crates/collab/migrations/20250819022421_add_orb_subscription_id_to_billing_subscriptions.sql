alter table billing_subscriptions
    add column orb_subscription_id text;
