ALTER TABLE extension_versions ADD COLUMN wasm_api_version TEXT;
