ALTER TABLE "project_repositories" ADD COLUMN "merge_message" VARCHAR;
