alter table billing_customers
    add column trial_started_at timestamp without time zone;
