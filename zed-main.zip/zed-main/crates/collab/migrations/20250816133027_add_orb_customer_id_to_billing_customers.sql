alter table billing_customers
    add column orb_customer_id text;
