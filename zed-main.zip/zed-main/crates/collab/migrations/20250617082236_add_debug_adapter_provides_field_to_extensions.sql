alter table extension_versions
add column provides_debug_adapters bool not null default false
