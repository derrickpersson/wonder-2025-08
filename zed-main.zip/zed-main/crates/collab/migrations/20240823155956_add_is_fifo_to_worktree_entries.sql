ALTER TABLE "worktree_entries"
ADD "is_fifo" BOOL NOT NULL DEFAULT FALSE;
