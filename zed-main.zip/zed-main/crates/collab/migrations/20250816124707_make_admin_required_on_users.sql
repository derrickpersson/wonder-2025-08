alter table users
alter column admin set not null;
