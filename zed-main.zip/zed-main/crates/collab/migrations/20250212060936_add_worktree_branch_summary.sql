ALTER TABLE worktree_repositories ADD COLUMN branch_summary TEXT NULL;
