ALTER TABLE projects DROP COLUMN remote_project_id;
DROP TABLE remote_projects;
