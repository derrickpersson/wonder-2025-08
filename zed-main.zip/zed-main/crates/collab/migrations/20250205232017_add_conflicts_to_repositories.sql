ALTER TABLE worktree_repositories
ADD COLUMN current_merge_conflicts VARCHAR NULL;
