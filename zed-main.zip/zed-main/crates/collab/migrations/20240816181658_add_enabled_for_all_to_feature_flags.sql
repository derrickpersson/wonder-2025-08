alter table feature_flags add column enabled_for_all boolean not null default false;
