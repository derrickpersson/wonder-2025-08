alter table project_collaborators
    add column committer_name varchar;
alter table project_collaborators
    add column committer_email varchar;
