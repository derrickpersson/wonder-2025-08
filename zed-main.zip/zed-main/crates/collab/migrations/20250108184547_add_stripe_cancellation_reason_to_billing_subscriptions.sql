alter table billing_subscriptions
add column stripe_cancellation_reason text;
