alter table project_repositories
    add column head_commit_details varchar;
