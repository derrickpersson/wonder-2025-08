alter table users add column custom_llm_monthly_allowance_in_cents integer;
